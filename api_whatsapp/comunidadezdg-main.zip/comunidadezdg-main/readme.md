# BOT ZDG

Olá, essa é uma implementação da biblioteca <a href="https://github.com/pedroslopez/whatsapp-web.js">wweb.js</a>

Conheça o canal da Comunidade ZDG:

- <a href="https://www.youtube.com/channel/UCrPbAoQKz42Gm0mLdWatAEA">Comunidade ZDG</a>


### Como usar?

- git clone https://github.com/pedroherpeto/comunidadezdg.git
- cd comunidadezdg
- Rodar `npm install`
- Rodar `npm start`
- Abrir o browser no endereço `http://localhost:8000`
- Ler o QRCode na tela


## Conheça a Comunidade ZDG

🤑 Garanta sua renda extra explorando todo o poder da API de graça, mesmo que você nao seja programador, clicando no link <a href="https://comunidadezdg.com.br">Comunidade ZDG</a>. Obrigado =)

